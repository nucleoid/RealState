class PropertyType < Enumeration
  self.add :APARTMENT, { description: 'Single Apartment Unit' }
  self.add :DETACHED_HOME, { description: 'Detached Home' }
end